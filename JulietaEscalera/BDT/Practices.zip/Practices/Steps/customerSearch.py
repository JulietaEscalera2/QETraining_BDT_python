import search
from compare import *

@given(u'I have ListOfClients')
def step_impl(context):
 a=1
    

@when(u'I search a client  {NameClient}, {IDClient} , ${TotalPricedOfPurchase}')
def step_impl(context,NameClient,IDClient,TotalPricedOfPurchase):
	context.total=int(TotalPricedOfPurchase)
	context.totalPrice=search.searchUser(NameClient,IDClient,TotalPricedOfPurchase)
	print (search.searchUser(NameClient,IDClient,TotalPricedOfPurchase))

@then(u'It should return ${TotalPricedOfPurchase}')
def step_impl(context,TotalPricedOfPurchase):
	expect(totalPrice).to_equal(int(total))
    
