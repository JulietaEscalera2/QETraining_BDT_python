@given(u'I have to complete {form}')
def step_impl(context, form):
    raise context.form=form

@when(u'I insert \'ZipCode\' {number:d}')
def step_impl(context, number):
	print("ZipCode",number)
   

@when(u'I insert \'Country\' {letters:w}')
def step_impl(context,letters):
    print("Country",letters)

@when(u'I insert \'Number of Habitants\' {thousands:e}')
def step_impl(context,thousands):
    print("Country",thousands)
	
	
@given(u'The user has to complete a form')
def step_impl(context):
    print('Given The user has to complete a form')

@when(u'The user inserts Name: {name:w})
def step_impl(context,name):
    print('When The user inserts Name: Julian_Matias')

@when(u'The user inserts Last Name: {lastname:w})
def step_impl(context,lastname):
    print('When The user inserts Last Name: Delgadillo_Escalera')

@when(u'The user inserts password: {pass:W})
def step_impl(context,pass):
  context.pass=pass
    print(context.pass)

@when(u'The user confirms the password')
def step_impl(context:W):
    print('When The user confirms the password')

@when(u'The user chooses Birthday: month day year: {month:w},{day:d},{year:d}')
def step_impl(context, month, day, year):
    print('When The user chooses Birthday: month day year: May,10,1995')

@when(u'The user chooses Gender: {gender}')
def step_impl(context, gender):
    print('When The user chooses Gender: Male')

@when(u'The user is choosing operator as {code} and insert phone number as {phone}')
def step_impl(context, code, phone):
    print('When The user is choosing operator as "BOL" and insert phone number as 70774289')

@when(u'The user inserts e-mail address as : {email:W}')
def step_impl(context,email):
    print('When The user inserts e-mail address as : test@test.com')

@when(u'The user press create button')
def step_impl(context):
    print('When The user press create button')

@then(u'The user can insert user and password')
def step_impl(context):
    print('Then The user can insert user and password')

@then(u'Press Login button')
def step_impl(context):
    print('Then Press Login button')

@then(u'The user is in their account')
def step_impl(context):
    print('Then The user is in their account')