@given(u'I have ${balance} in my account # the context')
def step_impl(context,balance:d):
    context.balance=balance

@when(u'I request ${required} # the event(s)')
def step_impl(context):
    a=1

@then(u'$20 should be dispensed # the outcome(s)')
def step_impl(context):
    b=0