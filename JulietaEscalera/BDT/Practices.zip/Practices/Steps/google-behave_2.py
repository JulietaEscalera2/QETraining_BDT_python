
#Instead of run example.feature for practice related to Behave_3_1 I put all steps definitions
# Steps definitions for glogle main page feature

#Given as preconditions
#When as actions or internal steps
#Then as Asserts

@given(u'I insert "Google URL" in url bar')
def step_impl(context):
    raise NotImplementedError(u'STEP: Given I insert "Google URL" in url bar')

@when(u'I press \'Insert\' button')
def step_impl(context):
    raise NotImplementedError(u'STEP: When I press \'Insert\' button')

@then(u'The google main page should be displayed')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then The google main page should be displayed')

@given(u'I am in "Google" web page')
def step_impl(context):
    raise NotImplementedError(u'STEP: Given I am in "Google" web page')

@given(u'I have "text" to search')
def step_impl(context):
    raise NotImplementedError(u'STEP: Given I have "text" to search')

@given(u'I press \'Google Search\' button')
def step_impl(context):
    raise NotImplementedError(u'STEP: Given I press \'Google Search\' button')

@given(u'I resieve a list of URL_matches')
def step_impl(context):
    raise NotImplementedError(u'STEP: Given I resieve a list of URL_matches')

@when(u'I press \'I\'m Feeling Lucky\' button')
def step_impl(context):
    raise NotImplementedError(u'STEP: When I press \'I\'m Feeling Lucky\' button')

@then(u'I pass to another navegation page')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then I pass to another navegation page')

@when(u'Close "Come here often? Make Google your homepage." panel')
def step_impl(context):
    raise NotImplementedError(u'STEP: When Close "Come here often? Make Google your homepage." panel')

@when(u'I explore page with \'TAB\' keyword')
def step_impl(context):
    raise NotImplementedError(u'STEP: When I explore page with \'TAB\' keyword')

@then(u'I can select \'About\' option')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then I can select \'About\' option')

@then(u'I can select \'Store\' option too')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then I can select \'Store\' option too')

@then(u'I can select \'Other\'link options')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then I can select \'Other\'link options')