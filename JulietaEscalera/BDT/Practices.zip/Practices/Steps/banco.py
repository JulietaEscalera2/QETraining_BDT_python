from compare import *
@given(u'I have ${MontoEnMiCuenta} in my account')
def step_impl(context,MontoEnMiCuenta):
	context.MontoEnMiCuenta=int(MontoEnMiCuenta)   

@when(u'I choose to withdraw the fixed amount of ${MontoAretirar}')
def step_impl(context,MontoAretirar):
	context.MontoAretirar=int(MontoAretirar)    

@then(u'I should receive ${MontoRecibido} cash')
def step_impl(context,MontoRecibido):
	print("This is your $", MontoRecibido)   

@then(u'the balance of my account should be ${Saldo}')
def step_impl(context,Saldo):
	context.saldoCuenta=context.MontoEnMiCuenta-context.MontoAretirar
	expect(context.saldoCuenta).to_equal(int(Saldo))